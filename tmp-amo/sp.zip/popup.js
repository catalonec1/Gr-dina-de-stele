/* SQL Pocket – popup UI */
(function () {
  'use strict';
  const T = self.SqlTools;
  const CFG = self.SQLP_CONFIG;
  const $ = id => document.getElementById(id);
  const api = typeof chrome !== 'undefined' && chrome.storage ? chrome : null;

  const local = {
    async get(k) { if (api) return api.storage.local.get(k); try { return { [k]: JSON.parse(localStorage.getItem(k)) }; } catch (e) { return {}; } },
    async set(o) { if (api) return api.storage.local.set(o); for (const k in o) localStorage.setItem(k, JSON.stringify(o[k])); },
    async remove(k) { if (api) return api.storage.local.remove(k); localStorage.removeItem(k); }
  };
  const sync = api ? api.storage.sync : local;
  const license = self.SqlpLicense.createLicense({ fetch: self.fetch.bind(self), storage: sync, config: CFG });

  let isPro = false;
  let snippets = [];

  function toast(msg) {
    const el = $('toast'); el.textContent = msg; el.classList.add('show');
    clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 1600);
  }
  async function copy(text) {
    if (!text) return toast('Nothing to copy');
    try { await navigator.clipboard.writeText(text); toast('Copied'); }
    catch (e) { const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); toast('Copied'); }
  }

  // ---- tabs ----
  function showTab(name) {
    document.querySelectorAll('nav button').forEach(b => b.setAttribute('aria-selected', String(b.dataset.tab === name)));
    document.querySelectorAll('[role=tabpanel]').forEach(p => { p.hidden = p.id !== 'tab-' + name; });
    local.set({ lastTab: name });
  }
  document.querySelectorAll('nav button').forEach(b => b.addEventListener('click', () => showTab(b.dataset.tab)));

  // ---- settings ----
  async function loadSettings() {
    const s = (await local.get('settings')).settings || {};
    if (s.kwCase) $('kwCase').value = s.kwCase;
    if (s.indent) $('indent').value = s.indent;
    if (s.codeLang) $('codeLang').value = s.codeLang;
    if (s.csvDialect) $('csvDialect').value = s.csvDialect;
    if (s.csvMode) $('csvMode').value = s.csvMode;
  }
  function saveSettings() {
    local.set({ settings: { kwCase: $('kwCase').value, indent: $('indent').value, codeLang: $('codeLang').value, csvDialect: $('csvDialect').value, csvMode: $('csvMode').value } });
  }
  ['kwCase', 'indent', 'codeLang', 'csvDialect', 'csvMode'].forEach(id => $(id).addEventListener('change', saveSettings));

  // ---- format ----
  function fmtOpts() { const v = $('indent').value; return { keywordCase: $('kwCase').value, indent: v === 'tab' ? '\t' : Number(v) }; }
  $('fmtBtn').addEventListener('click', () => { $('fmtIn').value = T.formatSql($('fmtIn').value, fmtOpts()); });
  $('minBtn').addEventListener('click', () => { $('fmtIn').value = T.minifySql($('fmtIn').value, { keywordCase: $('kwCase').value }); });
  $('fmtCopy').addEventListener('click', () => copy($('fmtIn').value));
  $('fmtIn').addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); $('fmtBtn').click(); }
  });
  $('fmtSave').addEventListener('click', () => addSnippet($('fmtIn').value));

  // ---- IN list ----
  $('inBtn').addEventListener('click', () => {
    const r = T.buildInList($('inIn').value, { quote: $('inQuote').value, distinct: $('inDistinct').checked, column: $('inCol').value || 'col' });
    $('inOut').textContent = r.sql;
    toast(r.count + ' values' + (r.chunks > 1 ? ', ' + r.chunks + ' chunks' : ''));
  });
  $('inCopy').addEventListener('click', () => copy($('inOut').textContent));

  // ---- code string ----
  $('wrapBtn').addEventListener('click', () => { $('codeOut').textContent = T.toCodeString($('codeIn').value, $('codeLang').value); });
  $('unwrapBtn').addEventListener('click', () => {
    if (!isPro) { showTab('pro'); return toast('Code → SQL is a Pro feature'); }
    $('codeOut').textContent = T.formatSql(T.fromCodeString($('codeIn').value), fmtOpts());
  });
  $('codeCopy').addEventListener('click', () => copy($('codeOut').textContent));

  // ---- CSV ----
  $('csvBtn').addEventListener('click', () => {
    const r = T.csvToInsert($('csvIn').value, {
      table: $('csvTable').value || 'my_table', dialect: $('csvDialect').value, mode: $('csvMode').value,
      header: $('csvHeader').checked, dates: $('csvDates').checked, maxRows: isPro ? Infinity : CFG.FREE_LIMITS.csvRows
    });
    $('csvOut').textContent = r.sql;
    const info = $('csvInfo');
    info.classList.toggle('warn', !!r.truncated);
    info.textContent = r.truncated
      ? `Free version: first ${r.rows} of ${r.total} rows. Get Pro for unlimited rows.`
      : (r.rows ? `${r.rows} rows, delimiter ${JSON.stringify(r.delim)}` : '');
  });
  $('csvCopy').addEventListener('click', () => copy($('csvOut').textContent));

  // ---- snippets ----
  async function loadSnippets() { snippets = (await local.get('snippets')).snippets || []; renderSnippets(); }
  async function addSnippet(text) {
    text = (text || '').trim();
    if (!text) return toast('Nothing to save');
    if (!isPro && snippets.length >= CFG.FREE_LIMITS.snippets) { showTab('pro'); return toast(`Free version keeps ${CFG.FREE_LIMITS.snippets} snippets`); }
    const firstLine = text.split('\n').find(l => l.trim()) || 'snippet';
    snippets.unshift({ id: Date.now().toString(36), title: firstLine.slice(0, 60), sql: text, at: Date.now() });
    await local.set({ snippets });
    renderSnippets(); toast('Saved to snippets');
  }
  function renderSnippets() {
    const q = $('snipSearch').value.toLowerCase();
    const list = $('snipList'); list.textContent = '';
    snippets.filter(s => !q || s.title.toLowerCase().includes(q) || s.sql.toLowerCase().includes(q)).forEach(s => {
      const li = document.createElement('li');
      const t = document.createElement('div'); t.className = 't';
      const b = document.createElement('b'); b.textContent = s.title; t.appendChild(b);
      const mk = (label, fn) => { const x = document.createElement('button'); x.textContent = label; x.addEventListener('click', fn); t.appendChild(x); };
      mk('Copy', () => copy(s.sql));
      mk('Edit', () => { $('fmtIn').value = s.sql; showTab('format'); });
      mk('✕', async () => { snippets = snippets.filter(x => x.id !== s.id); await local.set({ snippets }); renderSnippets(); });
      const pre = document.createElement('pre'); pre.textContent = s.sql;
      li.append(t, pre); list.appendChild(li);
    });
    $('snipCount').textContent = isPro ? `${snippets.length} saved` : `${snippets.length} / ${CFG.FREE_LIMITS.snippets} (free)`;
    if (!snippets.length) { const li = document.createElement('li'); li.className = 'hint'; li.textContent = 'No snippets yet. Use “☆ Save” on the Format tab.'; list.appendChild(li); }
  }
  $('snipSearch').addEventListener('input', renderSnippets);

  // ---- Pro ----
  function applyPro(state) {
    isPro = !!state.pro;
    document.body.classList.toggle('pro', isPro);
    $('proBadge').hidden = !isPro;
    $('proFree').hidden = isPro;
    $('proActive').hidden = !isPro;
    if (isPro && state.license) $('licShown').textContent = state.license.key.replace(/^(.{4}).*(.{4})$/, '$1…$2');
    renderSnippets();
  }
  const storeReady = /^https:\/\//.test(CFG.CHECKOUT_URL) && !/REPLACE/.test(CFG.CHECKOUT_URL);
  $('buyLink').href = storeReady ? CFG.CHECKOUT_URL : '#';
  $('proSoon').hidden = storeReady;
  $('buyRow').hidden = !storeReady;
  $('licRow').hidden = !storeReady;
  $('licActivate').addEventListener('click', async () => {
    const msg = $('licMsg'); msg.textContent = 'Checking…';
    const r = await license.activate($('licKey').value, 'SQL Pocket ' + (navigator.userAgent.includes('Firefox') ? 'Firefox' : 'Chrome'));
    if (r.ok) { msg.textContent = ''; applyPro({ pro: true, license: r.license }); toast('Pro activated'); }
    else msg.textContent = ({ invalid_format: 'That does not look like a license key.', network: 'No connection to the license server. Try again.', wrong_product: 'This key belongs to another product.' })[r.error] || ('Not activated: ' + r.error);
  });
  $('licDeactivate').addEventListener('click', async () => { await license.deactivate(); applyPro({ pro: false }); toast('Deactivated'); });

  // ---- full tab ----
  const params = new URLSearchParams(location.search);
  if (params.get('full') === '1') { document.body.classList.add('fulltab'); $('openTab').hidden = true; }
  $('openTab').addEventListener('click', () => {
    const url = (api ? api.runtime.getURL('popup.html') : 'popup.html') + '?full=1';
    if (api && api.tabs) api.tabs.create({ url }); else window.open(url);
    window.close();
  });

  // ---- init ----
  (async function init() {
    await loadSettings();
    await loadSnippets();
    let tab = params.get('tab') || (await local.get('lastTab')).lastTab || 'format';
    // Text sent from the context menu ("Format SQL with SQL Pocket")
    if (api && api.storage.session) {
      const p = (await api.storage.session.get('pending')).pending;
      if (p && p.text) {
        await api.storage.session.remove('pending');
        if (p.action === 'inlist') { $('inIn').value = p.text; tab = 'inlist'; $('inBtn').click(); }
        else { $('fmtIn').value = T.formatSql(p.text, fmtOpts()); tab = 'format'; }
      }
    }
    showTab(tab);
    applyPro(await license.validate(false));
    // Revalidate in the background when due (does not block the UI).
    license.validate(false).then(applyPro).catch(() => {});
  })();
})();
