/* SQL Pocket – background (MV3 service worker in Chrome, event page in Firefox) */
const ext = typeof browser !== 'undefined' ? browser : chrome;

ext.runtime.onInstalled.addListener(() => {
  ext.contextMenus.removeAll(() => {
    ext.contextMenus.create({ id: 'sqlp-format', title: 'Format SQL with SQL Pocket', contexts: ['selection'] });
    ext.contextMenus.create({ id: 'sqlp-inlist', title: 'Build IN (…) list from selection', contexts: ['selection'] });
  });
});

ext.contextMenus.onClicked.addListener(async (info) => {
  const text = info.selectionText || '';
  if (!text) return;
  const action = info.menuItemId === 'sqlp-inlist' ? 'inlist' : 'format';
  await ext.storage.session.set({ pending: { text, action, at: Date.now() } });
  try {
    await ext.action.openPopup();
  } catch (e) {
    await ext.tabs.create({ url: ext.runtime.getURL('popup.html') + '?full=1&tab=' + action });
  }
});
