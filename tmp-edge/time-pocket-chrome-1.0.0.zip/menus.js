var MENUS = [
  { id: 'tp-stamp', title: 'Convert “%s” with Time Pocket', tab: 'stamp' },
  { id: 'tp-cron', title: 'Explain cron “%s”', tab: 'cron' }
];
