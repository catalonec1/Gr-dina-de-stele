(function () {
  'use strict';
  const T = TimeTools; const $ = Shell.$;
  const LOCAL = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  const store = (k, v) => { try { if (v === undefined) return JSON.parse(localStorage.getItem(k)); localStorage.setItem(k, JSON.stringify(v)); } catch (e) { return null; } };
  const pad = n => String(n).padStart(2, '0');
  const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  function rows(table, data) {
    table.innerHTML = '';
    data.forEach(([k, v, extra]) => {
      const tr = document.createElement('tr'); const a = document.createElement('td'); const b = document.createElement('td');
      a.textContent = k; b.textContent = v; tr.append(a, b); if (extra) tr.append(extra);
      tr.addEventListener('click', e => { if (e.target.tagName !== 'BUTTON') Shell.copy(v); }); table.append(tr);
    });
  }

  // ---- Timestamp ----
  function tick() { const n = Date.now(); $('now').textContent = Math.floor(n / 1000) + '  ·  ' + n + ' ms  ·  ' + new Date(n).toISOString(); }
  function stamp() {
    const r = T.parseInstant($('ts').value);
    if (!r) { $('tsMsg').textContent = $('ts').value.trim() ? 'Not a timestamp or date I can read.' : ''; $('tsMsg').className = 'hint err'; $('tsOut').innerHTML = ''; return; }
    const d = new Date(r.ms);
    if (Number.isNaN(d.getTime())) { $('tsMsg').textContent = 'Out of range.'; $('tsMsg').className = 'hint err'; return; }
    $('tsMsg').textContent = 'Read as ' + r.unit + '.'; $('tsMsg').className = 'hint ok';
    const off = T.offset(r.ms, LOCAL);
    rows($('tsOut'), [
      ['Local (' + LOCAL + ')', T.inZone(r.ms, LOCAL) + '  ' + T.fmtOffset(off)],
      ['UTC', T.inZone(r.ms, 'UTC')],
      ['ISO 8601', d.toISOString()],
      ['ISO local', ymd(d) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) + T.fmtOffset(off).slice(3)],
      ['RFC 2822', d.toUTCString()],
      ['Unix seconds', String(Math.floor(r.ms / 1000))],
      ['Unix milliseconds', String(r.ms)],
      ['Relative', T.relative(r.ms)],
      ['ISO week', (w => w.year + '-W' + pad(w.week))(T.isoWeek(ymd(d))) + ', day ' + (((d.getDay() + 6) % 7) + 1) + ' of week'],
      ['Day of year', String(Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(d.getFullYear(), 0, 0)) / 86400000))]
    ]);
  }
  $('ts').addEventListener('input', stamp);
  $('useNow').addEventListener('click', () => { $('ts').value = String(Math.floor(Date.now() / 1000)); stamp(); });

  // ---- Time zones ----
  let ALL = [];
  try { ALL = Intl.supportedValuesOf('timeZone'); } catch (e) { /* older engines */ }
  if (!ALL.includes('UTC')) ALL.unshift('UTC');
  if (!ALL.includes(LOCAL)) ALL.unshift(LOCAL);
  let zones = store('zones') || [LOCAL, 'UTC', 'America/New_York', 'Europe/London', 'Asia/Tokyo'].filter((z, i, a) => a.indexOf(z) === i);
  [$('zFrom'), $('zAdd')].forEach(sel => ALL.forEach(z => { const o = document.createElement('option'); o.value = o.textContent = z; sel.append(o); }));
  $('zFrom').value = LOCAL; $('zAdd').value = 'Asia/Kolkata';
  function zNow() { const d = new Date(); $('zDate').value = ymd(d); $('zTime').value = pad(d.getHours()) + ':' + pad(d.getMinutes()); $('zFrom').value = LOCAL; zoneTable(); }
  function zoneTable() {
    const [y, m, d] = ($('zDate').value || ymd(new Date())).split('-').map(Number);
    const [h, mi] = ($('zTime').value || '00:00').split(':').map(Number);
    const ms = T.fromZone(y, m, d, h, mi, $('zFrom').value);
    rows($('zOut'), zones.map(z => {
      const del = document.createElement('td'); const b = document.createElement('button'); b.className = 'ghost'; b.textContent = '×'; b.title = 'Remove';
      b.addEventListener('click', () => { zones = zones.filter(x => x !== z); store('zones', zones); zoneTable(); }); del.append(b);
      return [z + ' (' + T.fmtOffset(T.offset(ms, z)) + ')', T.inZone(ms, z).replace(/:\d\d$/, ''), del];
    }));
  }
  ['zDate', 'zTime', 'zFrom'].forEach(id => $(id).addEventListener('input', zoneTable));
  $('zNow').addEventListener('click', zNow);
  $('zAddBtn').addEventListener('click', () => { const z = $('zAdd').value; if (!zones.includes(z)) { zones.push(z); store('zones', zones); } zoneTable(); });

  // ---- Date calc ----
  function between() {
    const a = $('dA').value, b = $('dB').value; if (!a || !b) return;
    const r = T.diff(a, b); const incl = $('dIncl').checked ? r.sign : 0;
    const cards = [
      [r.days + incl, 'calendar days'],
      [r.workdays + ($('dIncl').checked && ![0, 6].includes(new Date(b + 'T00:00:00Z').getUTCDay()) ? r.sign : 0), 'workdays (Mon–Fri)'],
      [r.weeks + ' w ' + r.weekRest + ' d', 'weeks'],
      [(r.years ? r.years + ' y ' : '') + r.months + ' m ' + r.restDays + ' d', 'years / months / days'],
      [Math.abs(r.days + incl) * 24, 'hours'],
      [T.isoWeek(b).week, 'ISO week of end date']
    ];
    $('dCards').innerHTML = '';
    cards.forEach(([v, l]) => { const c = document.createElement('div'); c.className = 'card'; const bb = document.createElement('b'); bb.textContent = v; const s = document.createElement('span'); s.textContent = l; c.append(bb, s); c.addEventListener('click', () => Shell.copy(String(v))); $('dCards').append(c); });
    $('dMsg').textContent = r.sign < 0 ? 'End date is before start date (negative).' : '';
  }
  function addCalc() {
    if (!$('aBase').value) return;
    const n = Number($('aN').value) * Number($('aSign').value); if (!Number.isFinite(n)) return;
    const out = T.add($('aBase').value, Math.trunc(n), $('aUnit').value, $('aWork').checked);
    const wd = new Date(out + 'T00:00:00Z').toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });
    $('aOut').textContent = out + ' (' + wd + ')';
  }
  ['dA', 'dB', 'dIncl'].forEach(id => $(id).addEventListener('input', between));
  ['aBase', 'aSign', 'aN', 'aUnit', 'aWork'].forEach(id => $(id).addEventListener('input', addCalc));
  $('aOut').addEventListener('click', () => Shell.copy($('aOut').textContent.split(' ')[0]));

  // ---- Cron ----
  const PRESETS = [['Every 5 min', '*/5 * * * *'], ['Hourly', '0 * * * *'], ['Daily 02:00', '0 2 * * *'], ['Weekdays 9:00', '0 9 * * 1-5'], ['Monthly', '0 0 1 * *']];
  PRESETS.forEach(([l, e]) => { const b = document.createElement('button'); b.textContent = l; b.addEventListener('click', () => { $('cron').value = e; cron(); }); $('cronPresets').append(b); });
  function cron() {
    const e = $('cron').value; const utc = $('cronUtc').checked;
    try {
      $('cronDesc').textContent = T.describeCron(e); $('cronDesc').className = '';
      const runs = T.nextRuns(e, 8, Date.now(), utc);
      rows($('cronOut'), runs.map((ms, i) => ['#' + (i + 1) + ' · ' + T.relative(ms), T.inZone(ms, utc ? 'UTC' : LOCAL)]));
      store('cron', e);
    } catch (err) { $('cronDesc').textContent = err.message; $('cronDesc').className = 'err'; $('cronOut').innerHTML = ''; }
  }
  $('cron').addEventListener('input', cron); $('cronUtc').addEventListener('input', cron);

  window.onPending = p => {
    const t = p.text.trim();
    if (p.tab === 'cron') { $('cron').value = t; cron(); } else { $('ts').value = t.slice(0, 80); stamp(); }
  };
  // init
  const today = new Date(); const later = new Date(today.getFullYear(), 11, 31);
  $('dA').value = ymd(today); $('dB').value = ymd(later <= today ? new Date(today.getFullYear() + 1, 11, 31) : later); $('aBase').value = ymd(today);
  $('ts').value = String(Math.floor(Date.now() / 1000));
  const savedCron = store('cron'); if (savedCron) $('cron').value = savedCron;
  tick(); setInterval(tick, 1000); stamp(); zNow(); between(); addCalc(); cron();
  Shell.init();
})();
