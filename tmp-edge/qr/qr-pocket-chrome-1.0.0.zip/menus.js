var MENUS = [
  { id: 'qp-make', title: 'Make QR code for “%s”', tab: 'text' }
];
