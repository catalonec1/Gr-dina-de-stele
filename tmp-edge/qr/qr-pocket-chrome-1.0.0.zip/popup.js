(function () {
  'use strict';
  const Q = QRTools; const $ = Shell.$;
  const store = (k, v) => { try { if (v === undefined) return JSON.parse(localStorage.getItem(k)); localStorage.setItem(k, JSON.stringify(v)); } catch (e) { return null; } };

  let tab = 'text', msgKind = 'email', current = null, payload = '';
  const FIELDS = ['tIn', 'wSsid', 'wEnc', 'wHidden', 'vFirst', 'vLast', 'vOrg', 'vTitle', 'vPhone', 'vMobile', 'vEmail', 'vUrl', 'vCity', 'vCountry', 'mTo', 'mPhone', 'mSubj', 'mBody', 'oEc', 'oSize', 'oMargin', 'oFg', 'oBg'];
  const val = id => { const el = $(id); return el.type === 'checkbox' ? el.checked : el.value; };

  // ---- Build the payload of the active tab ----
  function buildPayload() {
    if (tab === 'text') return $('tIn').value;
    if (tab === 'wifi') return $('wSsid').value ? Q.wifi({ ssid: $('wSsid').value, password: $('wPass').value, encryption: $('wEnc').value, hidden: $('wHidden').checked }) : '';
    if (tab === 'contact') {
      const c = { first: val('vFirst'), last: val('vLast'), org: val('vOrg'), title: val('vTitle'), phone: val('vPhone'), mobile: val('vMobile'), email: val('vEmail'), url: val('vUrl'), city: val('vCity'), country: val('vCountry') };
      return (c.first || c.last || c.org).trim() ? Q.vcard(c) : '';
    }
    if (msgKind === 'email') return $('mTo').value.trim() ? Q.email({ to: $('mTo').value, subject: $('mSubj').value, body: $('mBody').value }) : '';
    if (msgKind === 'sms') return $('mPhone').value.trim() ? Q.sms({ phone: $('mPhone').value, message: $('mBody').value }) : '';
    return $('mPhone').value.trim() ? Q.tel({ phone: $('mPhone').value }) : '';
  }
  const EMPTY = { text: 'Type a link or some text to see your QR code.', wifi: 'Enter the network name to make a Wi-Fi code.', contact: 'Enter a name or an organization.', message: 'Enter the recipient.' };

  // ---- Colors ----
  const lum = hex => { const v = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16) / 255).map(c => c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)); return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]; };
  function colorWarning() {
    const f = lum($('oFg').value), b = lum($('oBg').value);
    const ratio = (Math.max(f, b) + 0.05) / (Math.min(f, b) + 0.05);
    if (ratio < 3) return 'Low contrast between colors – many phones will not read it.';
    if (f > b) return 'Light code on dark background: some scanners cannot read inverted codes.';
    return '';
  }

  // ---- Render ----
  function draw(canvas, qr, px, margin, fg, bg) {
    const n = qr.size + margin * 2, k = Math.max(1, Math.floor(px / n));
    canvas.width = canvas.height = n * k;
    const g = canvas.getContext('2d');
    g.fillStyle = bg; g.fillRect(0, 0, n * k, n * k); g.fillStyle = fg;
    qr.modules.forEach((row, y) => row.forEach((d, x) => { if (d) g.fillRect((x + margin) * k, (y + margin) * k, k, k); }));
    return n * k;
  }
  function render() {
    payload = buildPayload();
    $('qPayload').textContent = payload;
    if (tab === 'text') {
      const bytes = Q.utf8(payload).length;
      $('tCount').textContent = payload ? `${[...payload].length} characters · ${bytes} bytes (max ${Q.maxBytes($('oEc').value)} at level ${$('oEc').value})` : '';
    }
    current = null; $('qWarn').textContent = '';
    if (!payload) { $('qr').hidden = true; $('qrEmpty').textContent = EMPTY[tab]; $('qMeta').textContent = ''; setButtons(false); saveForm(); return; }
    try { current = Q.encode(payload, { level: $('oEc').value }); }
    catch (e) {
      $('qr').hidden = true; $('qrEmpty').textContent = e.code === 'TOO_LONG' ? 'Too long for one QR code. Shorten the text or choose a lower error correction level.' : e.message;
      $('qMeta').textContent = ''; setButtons(false); saveForm(); return;
    }
    $('qr').hidden = false;
    const margin = +$('oMargin').value;
    draw($('qr'), current, 472, margin, $('oFg').value, $('oBg').value);
    const px = (current.size + margin * 2) * Math.max(1, Math.floor(+$('oSize').value / (current.size + margin * 2)));
    $('qMeta').textContent = `Version ${current.version} · ${current.size}×${current.size} · PNG ${px} px`;
    const w = colorWarning();
    $('qWarn').textContent = w || (current.version > 15 ? 'Dense code: print it at least 4 cm wide.' : '');
    setButtons(true); saveForm();
  }
  function setButtons(on) { ['dlPng', 'dlSvg', 'cpImg'].forEach(id => { $(id).disabled = !on; }); }

  // ---- Export ----
  const fileName = ext => 'qr-' + Q.kindOf(payload) + '-' + new Date().toISOString().slice(0, 10) + '.' + ext;
  function download(blob, name) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  function pngBlob() {
    const c = document.createElement('canvas');
    draw(c, current, +$('oSize').value, +$('oMargin').value, $('oFg').value, $('oBg').value);
    return new Promise(res => c.toBlob(res, 'image/png'));
  }
  $('dlPng').addEventListener('click', async () => { if (!current) return; download(await pngBlob(), fileName('png')); remember(); Shell.toast('PNG saved'); });
  $('dlSvg').addEventListener('click', () => {
    if (!current) return;
    const svg = Q.toSvg(current, { fg: $('oFg').value, bg: $('oBg').value, margin: +$('oMargin').value, px: +$('oSize').value });
    download(new Blob([svg], { type: 'image/svg+xml' }), fileName('svg')); remember(); Shell.toast('SVG saved');
  });
  $('cpImg').addEventListener('click', async () => {
    if (!current) return;
    try {
      if (typeof ClipboardItem === 'undefined') throw new Error('no ClipboardItem');
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': pngBlob() })]);
      Shell.toast('Image copied');
    } catch (e) { Shell.copy(payload); Shell.toast('Image copy not available here – text copied'); }
    remember();
  });

  // ---- History (only codes you download or copy) ----
  let hist = store('hist') || [];
  function remember() {
    hist = [{ p: payload, t: tab, at: Date.now() }, ...hist.filter(h => h.p !== payload)].slice(0, 12);
    store('hist', hist); drawHist();
  }
  const KIND = { wifi: 'Wi-Fi', contact: 'vCard', email: 'E-mail', sms: 'SMS', phone: 'Call', url: 'Link', text: 'Text' };
  function drawHist() {
    $('hist').innerHTML = '';
    hist.forEach(h => {
      const li = document.createElement('li'); const b = document.createElement('button');
      const k = document.createElement('span'); k.className = 'k'; k.textContent = KIND[Q.kindOf(h.p)];
      const l = document.createElement('span'); l.className = 'l'; l.textContent = Q.labelOf(h.p).replace(/^(Wi-Fi|Contact|E-mail|SMS|Phone): /, '');
      b.title = h.p; b.append(k, l);
      b.addEventListener('click', () => { $('tIn').value = h.p; Shell.selectTab('text'); render(); });
      li.append(b); $('hist').append(li);
    });
    $('hEmpty').hidden = hist.length > 0; $('hClear').hidden = !hist.length;
  }
  $('hClear').addEventListener('click', () => { hist = []; store('hist', hist); drawHist(); });

  // ---- Form state (the Wi-Fi password is never stored) ----
  function saveForm() { const o = {}; FIELDS.forEach(id => { o[id] = val(id); }); o.msgKind = msgKind; store('form', o); }
  function loadForm() {
    const o = store('form'); if (!o) return;
    FIELDS.forEach(id => { if (id in o) { const el = $(id); if (el.type === 'checkbox') el.checked = !!o[id]; else el.value = o[id]; } });
    if (o.msgKind) setKind(o.msgKind);
  }

  // ---- Message type ----
  function setKind(k) {
    msgKind = k;
    document.querySelectorAll('#mType button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.k === k)));
    $('mToL').hidden = k !== 'email'; $('mSubjL').hidden = k !== 'email';
    $('mPhoneL').hidden = k === 'email'; $('mBodyL').hidden = k === 'tel';
  }
  document.querySelectorAll('#mType button').forEach(b => b.addEventListener('click', () => { setKind(b.dataset.k); render(); }));

  $('wShow').addEventListener('click', () => { const p = $('wPass'); p.type = p.type === 'password' ? 'text' : 'password'; $('wShow').textContent = p.type === 'password' ? 'Show' : 'Hide'; });
  $('oSwap').addEventListener('click', () => { const t = $('oFg').value; $('oFg').value = $('oBg').value; $('oBg').value = t; render(); });
  $('oReset').addEventListener('click', () => { $('oFg').value = '#111827'; $('oBg').value = '#ffffff'; render(); });
  document.querySelectorAll('main input, main select, main textarea').forEach(el => el.addEventListener('input', render));

  window.onTab = name => { tab = name; render(); };
  window.onPending = p => { $('tIn').value = p.text.trim(); tab = 'text'; render(); };
  loadForm(); drawHist();
  if (!$('tIn').value) $('tIn').value = 'https://example.com/';
  Shell.init();
  render();
})();
