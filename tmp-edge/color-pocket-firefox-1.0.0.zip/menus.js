var MENUS = [
  { id: 'cp-convert', title: 'Convert color “%s” with Color Pocket', tab: 'convert' },
  { id: 'cp-contrast', title: 'Check contrast of “%s”', tab: 'contrast' }
];
