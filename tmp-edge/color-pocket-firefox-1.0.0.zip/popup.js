(function () {
  'use strict';
  const C = ColorTools; const $ = Shell.$;
  const store = (k, v) => { try { if (v === undefined) return JSON.parse(localStorage.getItem(k)); localStorage.setItem(k, JSON.stringify(v)); } catch (e) { return null; } };
  const css = c => `rgba(${Math.round(c.r)},${Math.round(c.g)},${Math.round(c.b)},${c.a ?? 1})`;
  const hex6 = c => C.rgbToHex({ ...c, a: 1 });
  // Any CSS color the browser knows (all 148 named colors etc.) via a canvas, after our own parser.
  const ctx = document.createElement('canvas').getContext('2d');
  function read(s) {
    const c = C.parse(s); if (c) return c;
    const t = String(s || '').trim(); if (!t || !ctx) return null;
    ctx.fillStyle = '#010203'; ctx.fillStyle = t; const v = ctx.fillStyle;
    if (v === '#010203' && !/^#?010203$/i.test(t)) return null;
    return C.parse(v);
  }
  function rows(table, data) {
    table.innerHTML = '';
    data.forEach(([k, v]) => {
      const tr = document.createElement('tr'); const a = document.createElement('td'); const b = document.createElement('td');
      a.textContent = k; b.textContent = v; tr.append(a, b); tr.addEventListener('click', () => Shell.copy(v)); table.append(tr);
    });
  }
  const textOn = c => C.contrast(C.flatten(c), { r: 0, g: 0, b: 0 }).ratio >= 7 ? '#000' : '#fff';

  // ---- Convert ----
  let hist = store('hist') || [];
  function drawHist() {
    $('cHist').innerHTML = '';
    hist.forEach(h => { const b = document.createElement('button'); b.style.background = h; b.title = h; b.addEventListener('click', () => { $('cIn').value = h; convert(); }); $('cHist').append(b); });
  }
  let histT;
  function convert() {
    const s = $('cIn').value; const c = read(s);
    if (!c) { $('cMsg').textContent = s.trim() ? 'Not a color I can read. Try #ff8800, rgb(255 136 0), hsl(32 100% 50%) or a CSS name.' : ''; $('cMsg').className = 'hint err'; $('cOut').innerHTML = ''; $('cSw').style.background = 'transparent'; return; }
    $('cMsg').textContent = ''; $('cSw').style.background = css(c); $('cPick').value = hex6(c);
    const f = C.formats(c);
    const onW = C.contrast(C.flatten(c), { r: 255, g: 255, b: 255 }).ratio, onB = C.contrast(C.flatten(c), { r: 0, g: 0, b: 0 }).ratio;
    f.push(['Contrast on white / black', onW + ' : 1  /  ' + onB + ' : 1']);
    rows($('cOut'), f); store('last', s);
    clearTimeout(histT); histT = setTimeout(() => { const h = C.rgbToHex(c); hist = [h, ...hist.filter(x => x !== h)].slice(0, 16); store('hist', hist); drawHist(); }, 900);
  }
  $('cIn').addEventListener('input', convert);
  $('cPick').addEventListener('input', () => { $('cIn').value = $('cPick').value; convert(); });
  if ('EyeDropper' in window) {
    $('cDrop').addEventListener('click', async () => { try { const r = await new window.EyeDropper().open(); $('cIn').value = r.sRGBHex; convert(); } catch (e) { /* cancelled */ } });
  } else { $('cDrop').hidden = true; }

  // ---- Contrast ----
  function contrast() {
    const fg = read($('kFg').value), bg = read($('kBg').value);
    if (!fg || !bg) { $('kMsg').textContent = 'Enter two valid colors.'; $('kMsg').className = 'hint err'; $('ratio').textContent = '–'; $('kBadges').innerHTML = ''; return; }
    const bgF = C.flatten(bg), fgF = C.flatten(fg, bgF);
    $('kFgPick').value = hex6(fg); $('kBgPick').value = hex6(bg);
    $('kPrev').style.background = css(bgF); $('kPrev').style.color = css(fgF);
    const r = C.contrast(fgF, bgF); $('ratio').textContent = r.ratio.toFixed(2) + ' : 1';
    $('kBadges').innerHTML = '';
    [['AA normal', r.aaNormal], ['AA large', r.aaLarge], ['AAA normal', r.aaaNormal], ['AAA large', r.aaaLarge]].forEach(([l, ok]) => {
      const s = document.createElement('span'); s.className = 'badge ' + (ok ? 'ok' : 'no'); s.textContent = (ok ? '✓ ' : '✗ ') + l; $('kBadges').append(s);
    });
    $('kMsg').className = 'hint';
    $('kMsg').textContent = r.aaNormal ? 'Readable for body text (WCAG 2.x).' : r.aaLarge ? 'Only for large text (24px, or 18.66px bold) and UI components.' : 'Too low for text. Darken or lighten one color.';
    store('k', [$('kFg').value, $('kBg').value]);
  }
  ['kFg', 'kBg'].forEach(id => $(id).addEventListener('input', contrast));
  $('kFgPick').addEventListener('input', () => { $('kFg').value = $('kFgPick').value; contrast(); });
  $('kBgPick').addEventListener('input', () => { $('kBg').value = $('kBgPick').value; contrast(); });
  $('kSwap').addEventListener('click', () => { const t = $('kFg').value; $('kFg').value = $('kBg').value; $('kBg').value = t; contrast(); });

  // ---- Palette ----
  let lastPal = null;
  function palette() {
    const c = read($('pIn').value);
    if (!c) { $('pMsg').textContent = 'Not a color I can read.'; $('pMsg').className = 'hint err'; $('pOut').innerHTML = ''; return; }
    $('pMsg').textContent = ''; $('pPick').value = hex6(c);
    const P = C.palettes({ ...c, a: 1 }); lastPal = P; $('pOut').innerHTML = '';
    [['Shades', 'shades', 'light → dark'], ['Complementary', 'complementary', ''], ['Analogous', 'analogous', '±30°'], ['Triadic', 'triadic', '120°'], ['Tetradic', 'tetradic', '90°']].forEach(([title, key, note]) => {
      const h = document.createElement('h2'); h.textContent = title + ' '; if (note) { const sm = document.createElement('small'); sm.textContent = note; h.append(sm); }
      const strip = document.createElement('div'); strip.className = 'strip';
      P[key].forEach(col => { const x = hex6(col); const b = document.createElement('button'); b.style.background = x; b.style.color = textOn(col); b.textContent = x; b.title = x; b.addEventListener('click', () => Shell.copy(x)); strip.append(b); });
      $('pOut').append(h, strip);
    });
    store('p', $('pIn').value);
  }
  $('pIn').addEventListener('input', palette);
  $('pPick').addEventListener('input', () => { $('pIn').value = $('pPick').value; palette(); });
  $('pCss').addEventListener('click', () => {
    if (!lastPal) return;
    const steps = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900];
    Shell.copy(':root {\n' + lastPal.shades.map((c, i) => `  --color-${steps[i]}: ${hex6(c)};`).join('\n') + '\n}');
  });

  window.onTab = name => { if (name === 'contrast') contrast(); if (name === 'palette') palette(); };
  window.onPending = p => {
    const t = p.text.trim().slice(0, 80);
    if (p.tab === 'contrast') { $('kFg').value = t; contrast(); } else { $('cIn').value = t; convert(); $('pIn').value = t; }
  };
  const k = store('k'); if (Array.isArray(k)) { $('kFg').value = k[0]; $('kBg').value = k[1]; }
  $('cIn').value = store('last') || '#3b82f6'; const p = store('p'); if (p) $('pIn').value = p;
  drawHist(); convert(); contrast(); palette();
  Shell.init();
})();
